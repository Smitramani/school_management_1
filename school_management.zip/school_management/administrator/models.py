from django.db import models
from login.models import CustomUser
from django.utils import timezone


# AcademicYear model
class AcademicYear(models.Model):
    start_year = models.IntegerField()
    end_year = models.IntegerField()
    is_active = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.start_year} - {self.end_year}"

# Shift model
class Shift(models.Model):
    name = models.CharField(max_length=255)
    start_time = models.TimeField()
    end_time = models.TimeField()

    def __str__(self):
        return self.name

# Teacher model
class Teacher(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    shift = models.ForeignKey(Shift, on_delete=models.SET_NULL, null=True)
    gender = models.CharField(max_length=10)
    photo = models.ImageField(upload_to='teacher/', null=True, blank=True)
    date_of_birth = models.DateField()
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    contact_no = models.CharField(max_length=15)
    address = models.TextField()
    academic_year = models.ForeignKey(AcademicYear, on_delete=models.SET_NULL, null=True)  # Added field

    def __str__(self):
        return f"{self.user.first_name} {self.user.last_name}"

#stander

class Standard(models.Model):
    CLASS_CHOICES = [(i, str(i)) for i in range(1, 13)]
    DIVISION_CHOICES = [('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')]

    class_field = models.IntegerField(choices=CLASS_CHOICES)
    division = models.CharField(max_length=1, choices=DIVISION_CHOICES)

    class Meta:
        unique_together = ('class_field', 'division')
        constraints = [
            models.UniqueConstraint(fields=['class_field', 'division'], name='unique_standard')
        ]

    def __str__(self):
        return f"{self.class_field}{self.division}"

#subject


class Subject(models.Model):
    subject_name = models.CharField(max_length=100)
    standard = models.ForeignKey(Standard, on_delete=models.CASCADE)

    def __str__(self):
        return self.subject_name


# Student model
from django.db import models
from django.db.models import Max

class Student(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    shift = models.ForeignKey(Shift, on_delete=models.SET_NULL, null=True)
    gender = models.CharField(max_length=10)
    roll_number = models.PositiveIntegerField(unique=False, null=True, blank=True)  # Changed to PositiveIntegerField
    photo = models.ImageField(upload_to='student/', null=True, blank=True)
    date_of_birth = models.DateField()
    contact_no = models.CharField(max_length=15)
    address = models.TextField()
    academic_year = models.ForeignKey(AcademicYear, on_delete=models.SET_NULL, null=True)
    standard = models.ForeignKey(Standard, on_delete=models.SET_NULL, null=True)  # Standard field

    def __str__(self):
        return f"{self.user.first_name} {self.user.last_name}"

    def save(self, *args, **kwargs):
        # Check if roll_number is not already assigned
        if not self.roll_number:
            # Get the highest roll_number for the selected standard
            last_roll = Student.objects.filter(standard=self.standard).aggregate(Max('roll_number'))
            max_roll = last_roll['roll_number__max']

            # If there are no students in this standard, start from 1
            if max_roll is not None:
                self.roll_number = max_roll + 1
            else:
                self.roll_number = 1  # Start from 1 for the first student in the standard

        super(Student, self).save(*args, **kwargs)

# techer attendace   


class TeacherAttendance(models.Model):
    STATUS_CHOICES = (
        ('P', 'Present'),
        ('A', 'Absent'),
    )
    
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    date = models.DateField()  # Change this line
    status = models.CharField(max_length=1, choices=STATUS_CHOICES)

    def __str__(self):
        return f"{self.teacher.user.first_name} {self.teacher.user.last_name} - {self.get_status_display()} on {self.date}"

#techer subject
from django.db import models
from .models import Teacher, Standard, Subject  # Assuming Standard, Subject, Teacher are defined elsewhere

class TeacherSubject(models.Model):
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    standard = models.ForeignKey(Standard, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('teacher', 'standard', 'subject')  # Prevent duplicate assignments

    def __str__(self):
        return f"{self.teacher} - {self.standard} - {self.subject}"


# fee

from django.db import models
from .models import Student  # Assuming Student model is in the same app

class Fee(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    due_date = models.DateField()
    payment_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=10, choices=[('Paid', 'Paid'), ('Unpaid', 'Unpaid')], default='Unpaid')

    def __str__(self):
        return f"{self.student.user.first_name} {self.student.user.last_name} - {self.amount} - {self.status}"

#student attendacnce

class StudentAttendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    date = models.DateField()
    status = models.CharField(max_length=10, choices=[('Present', 'Present'), ('Absent', 'Absent')])
    academic_year = models.ForeignKey(AcademicYear, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('student', 'date')

    def __str__(self):
        return f'{self.student.user.first_name} {self.student.user.last_name} - {self.date}'