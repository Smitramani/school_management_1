from django.db.models.signals import post_delete
from django.dispatch import receiver
from .models import Teacher

@receiver(post_delete, sender=Teacher)
def delete_teacher_related_data(sender, instance, **kwargs):
    # Delete the teacher's photo
    if instance.photo:
        instance.photo.delete(save=False)  # Deletes the photo file from the filesystem
    
    # Delete the associated CustomUser
    if instance.user:
        instance.user.delete()  # Deletes the related CustomUser instance


from django.db.models.signals import post_delete
from django.dispatch import receiver
from .models import Student

@receiver(post_delete, sender=Student)
def delete_student_related_data(sender, instance, **kwargs):
    # Delete the student's photo
    if instance.photo:
        instance.photo.delete(save=False)  # Deletes the photo file from the filesystem
    
    # Delete the associated CustomUser
    if instance.user:
        instance.user.delete()  # Deletes the related CustomUser instance
