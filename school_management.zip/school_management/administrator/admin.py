from django.contrib import admin
from .models import AcademicYear, Shift, Teacher 
from login.models import CustomUser

# Register AcademicYear model
@admin.register(AcademicYear)
class AcademicYearAdmin(admin.ModelAdmin):
    list_display = ('start_year', 'end_year', 'is_active')
    search_fields = ('start_year', 'end_year')
    list_filter = ('is_active',)

# Register Shift model
@admin.register(Shift)
class ShiftAdmin(admin.ModelAdmin):
    list_display = ('name', 'start_time', 'end_time')
    search_fields = ('name',)

# Register Teacher model
@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ('user', 'shift', 'gender', 'date_of_birth', 'salary', 'contact_no', 'academic_year')
    search_fields = ('user__first_name', 'user__last_name', 'contact_no', 'academic_year__start_year', 'academic_year__end_year')
    list_filter = ('shift', 'gender', 'academic_year')

#Register stander

from django.contrib import admin
from .models import Standard

class StandardAdmin(admin.ModelAdmin):
    list_display = ('id', 'class_field', 'division')  # Columns to display in the admin list view
    list_filter = ('class_field', 'division')         # Filters in the sidebar
    search_fields = ('class_field', 'division')       # Search box

admin.site.register(Standard, StandardAdmin)

#Register sbj

from django.contrib import admin
from .models import Subject

class SubjectAdmin(admin.ModelAdmin):
    list_display = ('subject_name', 'standard')  # Columns to display in the admin list view
    search_fields = ('subject_name',)  # Enable search by subject name
    list_filter = ('standard',)  # Filter by standard

admin.site.register(Subject, SubjectAdmin)

#student 

from django.contrib import admin
from .models import Student

class StudentAdmin(admin.ModelAdmin):
    list_display = ('user', 'standard', 'roll_number','shift', 'academic_year', 'contact_no')
    search_fields = ('user__first_name', 'user__last_name', 'standard__class')

admin.site.register(Student, StudentAdmin)

#techer addtnace

from django.contrib import admin
from .models import TeacherAttendance

@admin.register(TeacherAttendance)
class TeacherAttendanceAdmin(admin.ModelAdmin):
    list_display = ('teacher', 'date', 'status')
    list_filter = ('status', 'date')
    search_fields = ('teacher__user__first_name', 'teacher__user__last_name', 'date')
    date_hierarchy = 'date'

#techer subject

from django.contrib import admin
from .models import TeacherSubject

class TeacherSubjectAdmin(admin.ModelAdmin):
    list_display = ('teacher', 'standard', 'subject')
    search_fields = ('teacher__user__first_name', 'teacher__user__last_name', 'standard__class', 'subject__subject_name')
    list_filter = ('standard', 'subject')

admin.site.register(TeacherSubject, TeacherSubjectAdmin)
