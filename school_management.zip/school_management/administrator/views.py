from django.db import IntegrityError
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from login.models import CustomUser
from .forms import AcademicYearForm
from .models import AcademicYear, Teacher ,Student    # Import Teacher model



@login_required(login_url='login:login')
def admin_dashboard(request):
    users = CustomUser.objects.all()

    # Fetch the active academic year
    active_year = AcademicYear.objects.filter(is_active=True).first()

    # Handle the AcademicYear form
    if request.method == 'POST':
        form = AcademicYearForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('administrator:admin_dashboard')
    else:
        form = AcademicYearForm()

    # Fetch academic years
    academic_years = AcademicYear.objects.all()

    # Check for year activation or deactivation
    if request.method == 'POST' and 'year_id' in request.POST:
        year_id = request.POST.get('year_id')
        year = AcademicYear.objects.get(id=year_id)
        
        # Set all years to inactive first
        AcademicYear.objects.update(is_active=False)
        
        # Set the selected year to active
        year.is_active = True
        year.save()
        
        return redirect('administrator:admin_dashboard')

    # Calculate the total number of teachers
    total_teachers = Teacher.objects.count()
    total_students = Student.objects.count()


    # Pass users, form, academic years, active year, and total teachers to the template
    context = {
        'users': users,
        'form': form,
        'academic_years': academic_years,
        'active_year': active_year,
        'total_teachers': total_teachers,
        'total_students': total_students, 
    }

    return render(request, 'admin_dashboard.html', context)


#teacher 
# administrator/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator, EmailValidator
from django.contrib.auth.decorators import login_required
from login.models import CustomUser, Role
from .models import Teacher, Shift, AcademicYear

@login_required(login_url='login:login')
def add_teacher(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        password = request.POST['password']
        shift_id = request.POST['shift']
        gender = request.POST['gender']
        date_of_birth = request.POST['date_of_birth']
        salary = request.POST['salary']
        contact_no = request.POST['contact_no']
        address = request.POST['address']
        photo = request.FILES.get('photo')

        # Validate email uniqueness
        if CustomUser.objects.filter(email=email).exists():
            messages.error(request, "This email is already in use.", extra_tags='add-teacher')
            return redirect('administrator:add_teacher')

        # Validate contact number
        contact_validator = RegexValidator(regex=r'^\d{10}$', message="Contact number must be exactly 10 digits." )
        try:
            contact_validator(contact_no)
        except ValidationError:
            messages.error(request, "Contact number must be exactly 10 digits and contain only numbers." , extra_tags='add-teacher')
            return redirect('administrator:add_teacher')

        # Create CustomUser instance
        user = CustomUser.objects.create(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=make_password(password)
        )

        # Assign Role ID 2 (Teacher) to the user
        role = Role.objects.get(id=2)
        user.role = role
        user.save()

        # Get the active academic year
        active_academic_year = AcademicYear.objects.get(is_active=True)

        # Create Teacher instance linked to the user and active academic year
        shift = Shift.objects.get(id=shift_id)
        Teacher.objects.create(
            user=user,
            shift=shift,
            gender=gender,
            photo=photo,
            date_of_birth=date_of_birth,
            salary=salary,
            contact_no=contact_no,
            address=address,
            academic_year=active_academic_year
        )

       
        return redirect('administrator:manage_teacher')

    # Get all shifts to display in the form
    shifts = Shift.objects.all()

    return render(request, 'add_teacher.html', {
        'shifts': shifts
    })


#manage teacher 

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Teacher

@login_required(login_url='login:login')
def manage_teacher(request):
    if request.method == "POST" and 'delete_teacher_id' in request.POST:
        teacher_id = request.POST.get('delete_teacher_id')
        teacher = get_object_or_404(Teacher, id=teacher_id)
        user = teacher.user
        
        try:
            if user and user.id:  # Ensure the user has a valid ID
                teacher.delete()  # Delete the Teacher first
                user.delete()  # Then delete the associated CustomUser
            else:
                # Handle the case where the user is None or has no valid ID
                return render(request, 'manage_teacher.html', {
                    'teachers': Teacher.objects.select_related('user').all(),
                    'error': 'The associated user could not be deleted.'
                })
        except Exception as e:
            # Handle any errors that occur during deletion
            return render(request, 'manage_teacher.html', {
                'teachers': Teacher.objects.select_related('user').all(),
                'error': str(e)
            })

        return redirect('administrator:manage_teacher')  # Redirect back to the teacher list after deletion

    teachers = Teacher.objects.select_related('user').all()
    return render(request, 'manage_teacher.html', {'teachers': teachers})

# upate teacher

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from django.contrib import messages
from login.models import CustomUser  # Assuming this is your CustomUser model
from .models import Teacher, Shift

@login_required(login_url='login:login')
def update_teacher(request, teacher_id):
    teacher = get_object_or_404(Teacher, id=teacher_id)
    user = teacher.user  # Assuming teacher.user is linked to CustomUser

    if request.method == 'POST':
        # Update user fields
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')

        # Check if email is unique (excluding the current user's email)
        if CustomUser.objects.filter(email=email).exclude(id=user.id).exists():
            messages.error(request, "This email is already in use.", extra_tags='update-teacher')
            return redirect('administrator:update_teacher', teacher_id=teacher.id)

        user.first_name = first_name
        user.last_name = last_name
        user.email = email

        # Password handling
        password = request.POST.get('password')
        if password:
            user.set_password(password)

        # Update teacher fields
        teacher.shift_id = request.POST.get('shift')
        teacher.gender = request.POST.get('gender')
        teacher.date_of_birth = request.POST.get('date_of_birth')
        teacher.salary = request.POST.get('salary')
        teacher.contact_no = request.POST.get('contact_no')
        teacher.address = request.POST.get('address')

        # Validate contact number
        contact_no = teacher.contact_no
        contact_validator = RegexValidator(regex=r'^\d{10}$', message="Contact number must be exactly 10 digits.")
        try:
            contact_validator(contact_no)
        except ValidationError:
            messages.error(request, "Contact number must be exactly 10 digits and contain only numbers.", extra_tags='update-teacher')
            return redirect('administrator:update_teacher', teacher_id=teacher.id)

        # Save the user and teacher objects
        user.save()
        teacher.save()

        messages.success(request, "Teacher updated successfully.", extra_tags='update-teacher')
        return redirect('administrator:manage_teacher')

    # Pass the existing data to the template for pre-filling the form
    context = {
        'teacher': teacher,
        'shifts': Shift.objects.all(),  # Assuming Shift is a model
    }
    return render(request, 'update_teacher.html', context)

#satnder

# views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Standard

@login_required(login_url='login:login')
def add_standard(request):
    standards = Standard.objects.all()  # Fetch the list of standards from the database
    
    if request.method == 'POST':
        class_field = request.POST.get('class_field')
        division = request.POST.get('division')

        # Validation: Check if this combination already exists
        if Standard.objects.filter(class_field=class_field, division=division).exists():
            error_message = f"The standard {class_field}{division} already exists."
            return render(request, 'add_standard.html', {'error_message': error_message, 'standards': standards})

        # Save the new standard
        new_standard = Standard(class_field=class_field, division=division)
        new_standard.save()

        # Redirect with a success message
        messages.success(request, "Standard added successfully.",extra_tags='add_standard')
        return redirect('administrator:add_standard')  # Change the redirect URL if needed

    # If the request method is GET, just render the page with the list of standards
    return render(request, 'add_standard.html', {'standards': standards})


#sbject add

from django.shortcuts import render, redirect
from administrator.models import Subject

@login_required(login_url='login:login')
def add_subject(request):
    if request.method == 'POST':
        subject_name = request.POST.get('subject_name')
        standard_id = request.POST.get('standard')
        standard = Standard.objects.get(id=standard_id)
        
        # Create and save the new subject
        Subject.objects.create(subject_name=subject_name, standard=standard)
        return redirect('administrator:add_subject')  # Redirect to the list page after adding

    # Fetch existing subjects and standards
    subjects = Subject.objects.all()
    standards = Standard.objects.all()

    return render(request, 'add_subject.html', {'subjects': subjects, 'standards': standards})

#update subjet
from django.shortcuts import render, get_object_or_404, redirect
from administrator.models import Subject

@login_required(login_url='login:login')
def update_subject(request, subject_id):
    subject = get_object_or_404(Subject, id=subject_id)
    
    if request.method == 'POST':
        subject_name = request.POST.get('subject_name')
        standard_id = request.POST.get('standard')
        standard = Standard.objects.get(id=standard_id)
        
        # Update the subject fields
        subject.subject_name = subject_name
        subject.standard = standard
        subject.save()

        return redirect('administrator:add_subject')  # Redirect to the list after updating
    
    standards = Standard.objects.all()
    return render(request, 'update_subject.html', {'subject': subject, 'standards': standards})

#delete subject

@login_required(login_url='login:login')
def delete_subject(request, subject_id):
    subject = get_object_or_404(Subject, id=subject_id)
    subject.delete()
    return redirect('administrator:add_subject')  # Redirect to the list after deletion

from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from django.contrib import messages
from login.models import CustomUser, Role
from .models import Student, Shift, AcademicYear, Standard
from django.contrib.auth.decorators import login_required
from django.db.models import Max
from django.db import IntegrityError

@login_required(login_url='login:login')
def add_student(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        password = request.POST['password']
        shift_id = request.POST['shift']
        gender = request.POST['gender']
        date_of_birth = request.POST['date_of_birth']
        contact_no = request.POST['contact_no']
        address = request.POST['address']
        photo = request.FILES.get('photo')
        standard_id = request.POST['standard']

        # Validate email uniqueness
        if CustomUser.objects.filter(email=email).exists():
            messages.error(request, "A user with this email already exists.", extra_tags='add-student')
            return redirect('administrator:add_student')

        # Validate contact number
        contact_validator = RegexValidator(regex=r'^\d{10}$', message="Contact number must be exactly 10 digits.")
        try:
            contact_validator(contact_no)
        except ValidationError:
            messages.error(request, "Contact number must be exactly 10 digits and contain only numbers.", extra_tags='add-student')
            return redirect('administrator:add_student')

        # Create CustomUser instance
        user = CustomUser.objects.create(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=make_password(password)
        )

        # Assign Role ID 3 (Student) to the user
        role = Role.objects.get(id=3)  # Modify if necessary
        user.role = role
        user.save()

        # Get the active academic year
        active_academic_year = AcademicYear.objects.get(is_active=True)

        # Get the selected shift and standard
        shift = Shift.objects.get(id=shift_id)
        standard = Standard.objects.get(id=standard_id)

        # Find the highest roll number for the selected standard
        last_roll = Student.objects.filter(standard=standard).aggregate(Max('roll_number'))
        max_roll = last_roll['roll_number__max']
        if max_roll is not None:
            new_roll_number = max_roll + 1  # Increment the roll number for this standard
        else:
            new_roll_number = 1  # Start from 1 if no students exist in this standard

        # Create Student instance linked to the user and active academic year
        try:
            Student.objects.create(
                user=user,
                roll_number=new_roll_number,  # Auto-assigned roll number
                shift=shift,
                gender=gender,
                photo=photo,
                date_of_birth=date_of_birth,
                contact_no=contact_no,
                address=address,
                academic_year=active_academic_year,
                standard=standard
            )
            
        except IntegrityError:
            messages.error(request, "A student with this roll number already exists.", extra_tags='add-student')
            return redirect('administrator:add_student')

        return redirect('administrator:manage_student')  # Redirect to the admin dashboard

    # Get all shifts and standards to display in the form
    shifts = Shift.objects.all()
    standards = Standard.objects.all()

    return render(request, 'add_student.html', {
        'shifts': shifts,
        'standards': standards
    })

#manage student
from django.shortcuts import render, get_object_or_404, redirect
from .models import Student
from django.contrib.auth.decorators import login_required
from django.db.models import Q

@login_required(login_url='login:login')
def manage_student(request):
    search_query = request.GET.get('standard_search')  # Get the search query from the GET request

    if request.method == "POST" and 'delete_student_id' in request.POST:
        student_id = request.POST.get('delete_student_id')
        student = get_object_or_404(Student, id=student_id)
        user = student.user

        try:
            if user and user.id:
                student.delete()  # Delete the Student first
                user.delete()  # Then delete the associated CustomUser
            else:
                return render(request, 'manage_student.html', {
                    'students': Student.objects.select_related('user').all(),
                    'error': 'The associated user could not be deleted.'
                })
        except Exception as e:
            return render(request, 'manage_student.html', {
                'students': Student.objects.select_related('user').all(),
                'error': str(e)
            })

        return redirect('administrator:manage_student')  # Redirect back to the student list after deletion

    # Modify the filtering logic based on the search query
    if search_query:
        # Split the search query to check for class and division (e.g., '1A' -> class_field=1, division='A')
        class_part = ''.join(filter(str.isdigit, search_query))  # Extract the numeric class part
        division_part = ''.join(filter(str.isalpha, search_query))  # Extract the alphabetical division part

        # Filter students by class and division using Q objects for flexibility
        students = Student.objects.filter(
            Q(standard__class_field=class_part) & Q(standard__division=division_part)
        ).select_related('user')
    else:
        students = Student.objects.select_related('user').all()

    return render(request, 'manage_student.html', {'students': students, 'search_query': search_query})

#upadte student
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Student, Standard
from django.contrib import messages
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError

@login_required(login_url='login:login')
def update_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    user = student.user  # Assuming student.user is linked to CustomUser

    if request.method == 'POST':
        # Update user fields
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')
        user.email = request.POST.get('email')

        # Password update
        password = request.POST.get('password')
        if password:
            user.set_password(password)

        # Update student fields, excluding roll_number
        student.standard_id = request.POST.get('standard')
        student.gender = request.POST.get('gender')
        student.date_of_birth = request.POST.get('date_of_birth')
        student.contact_no = request.POST.get('contact_no')
        student.address = request.POST.get('address')

        # Validate contact number
        contact_validator = RegexValidator(regex=r'^\d{10}$', message="Contact number must be exactly 10 digits.")
        try:
            contact_validator(student.contact_no)
        except ValidationError:
            messages.error(request, "Contact number must be exactly 10 digits and contain only numbers.", extra_tags='add-student')
            return redirect('administrator:update_student', student_id=student_id)  # Redirect back to the form

        # Handle photo upload
        if 'photo' in request.FILES:
            student.photo = request.FILES['photo']

        # Save the user and student
        user.save()
        student.save()

        messages.success(request, "Student updated successfully.", extra_tags='update-student')  # Optionally add tags
        return redirect('administrator:manage_student')  # Redirect to manage_students view

    # Pass the existing data to the template for pre-filling the form
    context = {
        'student': student,
        'standards': Standard.objects.all(),  # Fetch all standards for dropdown
    }
    return render(request, 'update_student.html', context)


# techer attndeac
from django.shortcuts import render, redirect
from .models import Teacher, TeacherAttendance  # Ensure you have the correct imports
from django.contrib import messages
from django.contrib.auth.decorators import login_required

@login_required(login_url='login:login')
def teacher_attendance(request):
    if request.method == 'POST':
        selected_date = request.POST.get('date')  # Get the selected date from the form

        for teacher in Teacher.objects.all():  # Loop through all teachers
            attendance_status = request.POST.get(f'attendance_{teacher.id}')
            if attendance_status:
                # Split the attendance status to get teacher ID and status
                teacher_id, status = attendance_status.split('_')

                # Create or update attendance record for the selected date
                TeacherAttendance.objects.update_or_create(
                    date=selected_date,
                    teacher_id=teacher_id,
                    defaults={'status': status}
                )

        
        return redirect('administrator:view_attendance')  # Adjust to the correct redirect

    # For GET requests, render the attendance form
    teachers = Teacher.objects.all()  # Fetch all teachers
    return render(request, 'teacher_attendance.html', {'teachers': teachers})


@login_required(login_url='login:login')
def view_attendance(request):
    attendance_records = None

    if request.method == 'POST':
        date = request.POST.get('date')
        attendance_records = TeacherAttendance.objects.filter(date=date).select_related('teacher')

    return render(request, 'view_attendance.html', {'attendance_records': attendance_records})

from django.shortcuts import render, get_object_or_404, redirect
from .models import TeacherAttendance

# Update Attendance View
@login_required(login_url='login:login')
def update_attendance(request, record_id):
    attendance_record = get_object_or_404(TeacherAttendance, id=record_id)

    if request.method == 'POST':
        new_status = request.POST.get('status')
        attendance_record.status = new_status
        attendance_record.save()
        return redirect('administrator:view_attendance')

    return render(request, 'update_attendance.html', {'attendance_record': attendance_record})

# Delete Attendance View
@login_required(login_url='login:login')
def delete_attendance(request, record_id):
    attendance_record = get_object_or_404(TeacherAttendance, id=record_id)

    if request.method == 'POST':
        attendance_record.delete()
        return redirect('administrator:view_attendance')

    return redirect('administrator:view_attendance')  # Fallback in case of GET request

#techer subject

from django.shortcuts import render, redirect
from .models import TeacherSubject, Teacher, Standard, Subject
from django.contrib.auth.decorators import login_required

@login_required(login_url='login:login')
def add_teacher_subject(request):
    if request.method == 'POST':
        teacher_id = request.POST['teacher']
        standard_id = request.POST['standard']
        subject_id = request.POST['subject']

        teacher = Teacher.objects.get(id=teacher_id)
        standard = Standard.objects.get(id=standard_id)
        subject = Subject.objects.get(id=subject_id)

        # Create the TeacherSubject entry
        TeacherSubject.objects.create(teacher=teacher, standard=standard, subject=subject)

        return redirect('administrator:manage_teacher_subject')

    # Fetch all teachers, standards, and subjects to display in the form
    teachers = Teacher.objects.all()
    standards = Standard.objects.all()
    subjects = Subject.objects.all()

    return render(request, 'add_teacher_subject.html', {
        'teachers': teachers,
        'standards': standards,
        'subjects': subjects
    })

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import TeacherSubject

@login_required(login_url='login:login')
def manage_teacher_subject(request):
    if request.method == 'POST' and 'delete_assignment_id' in request.POST:
        assignment_id = request.POST.get('delete_assignment_id')
        teacher_subject = get_object_or_404(TeacherSubject, id=assignment_id)

        # Delete the selected teacher-subject assignment
        teacher_subject.delete()

        return redirect('administrator:manage_teacher_subject')

    # Fetch all teacher-subject assignments
    teacher_subjects = TeacherSubject.objects.select_related('teacher', 'standard', 'subject').all()

    return render(request, 'manage_teacher_subject.html', {
        'teacher_subjects': teacher_subjects
    })


from django.shortcuts import render
from administrator.models import StudentAttendance, Standard, Student
from .forms import StandardForm
from django.db.models import Q
from datetime import datetime

def student_attendance_view1(request):
    selected_standard = None
    selected_date = None
    attendance_records = None
    current_date = datetime.now().date()

    if request.method == 'POST':
        standard_form = StandardForm(request.POST)
        
        # Get selected date
        date_string = request.POST.get('date', current_date)
        selected_date = datetime.strptime(date_string, '%Y-%m-%d').date()

        # When the user selects the standard
        if 'select_standard' in request.POST and standard_form.is_valid():
            selected_standard = standard_form.cleaned_data['standard']
            # Filter attendance records by selected standard and date
            attendance_records = StudentAttendance.objects.filter(
                student__standard=selected_standard,
                date=selected_date
            )

    else:
        standard_form = StandardForm()
        selected_date = current_date  # Set default date to current date

    return render(request, 'student_attendance_view1.html', {
        'standard_form': standard_form,
        'attendance_records': attendance_records,
        'selected_standard': selected_standard,
        'selected_date': selected_date,
    })


